# Dashboard - Vibration Inference

Dashboard web sederhana (HTML + CSS + JavaScript, tanpa build tool) untuk menampilkan
hasil inferensi getaran dari ESP32 secara realtime lewat **MQTT over WebSocket**.

Dipakai bersama firmware [`VIBRATION_INFERENCE_MQTT_APP`](../VIBRATION_INFERENCE_MQTT_APP).

## Isi Folder

```text
DASHBOARD/
  index.html        Struktur halaman
  css/style.css     Tema terang & gelap, layout, komponen
  js/config.js      Broker, topic, dan parameter tampilan  <- yang paling sering diubah
  js/theme.js       Pergantian tema terang/gelap
  js/charts.js      Chart realtime (Chart.js)
  js/app.js         Koneksi MQTT, parsing payload, update UI
```

## Cara Menjalankan

1. Upload firmware `VIBRATION_INFERENCE_MQTT_APP` ke ESP32 dan pastikan serial monitor
   sudah menampilkan `[mqtt] publish #...`.
2. Buka `index.html` langsung di browser (double click sudah cukup, tidak perlu server).
3. Klik **Hubungkan**.

Kalau hardware belum siap, aktifkan **Mode demo** di control bar. Dashboard akan
memakai data simulasi dengan bentuk payload yang persis sama dengan firmware, jadi
tampilannya bisa dilatih tanpa perangkat.

> Dashboard butuh internet karena memakai broker publik HiveMQ dan CDN untuk
> `mqtt.js` + `Chart.js`.

## Konfigurasi

Semua nilai default ada di [`js/config.js`](js/config.js):

| Isian | Default | Keterangan |
| --- | --- | --- |
| `brokerUrl` | `wss://broker.hivemq.com:8884/mqtt` | Harus `wss://` karena diakses dari browser |
| `topic` | `ukara/aiot/hoc3/vibration/#` | Wildcard `#` menangkap semua device |
| `maxPoints` | `40` | Jumlah titik yang ditahan di grafik |
| `defaultThreshold` | `0.3` | Dipakai sebelum firmware mengirim field `threshold` |
| `staleAfterMs` | `10000` | Batas dianggap tidak ada data baru |

Broker dan topic juga bisa diubah langsung dari control bar tanpa mengedit file.

Kalau training dijalankan beberapa kelompok sekaligus di broker publik yang sama,
ganti `DEVICE_ID` di firmware masing-masing kelompok, lalu isi topic spesifik di
dashboard, misalnya `ukara/aiot/hoc3/vibration/esp32-01`.

## Format Payload

Firmware mengirim satu pesan JSON tiap window inferensi:

```json
{
  "device": "esp32-01",
  "uptime": 42310,
  "label": "getar-normal",
  "confidence": 0.9412,
  "status": "NORMAL",
  "threshold": 0.3,
  "anomaly": 0.1183,
  "classes": [
    { "label": "diam", "value": 0.0312 },
    { "label": "getar-normal", "value": 0.9412 },
    { "label": "getar-kasar", "value": 0.0276 }
  ],
  "timing": { "dsp": 6, "classification": 2, "anomaly": 1 },
  "heap": { "free": 198340, "total": 327680 }
}
```

`classes` sengaja berbentuk **array**, bukan object, supaya urutan label mengikuti
urutan model. Dashboard mengunci warna tiap kelas berdasarkan urutan ini, jadi satu
label selalu memakai warna yang sama sepanjang sesi.

## Yang Ditampilkan

| Panel | Isi |
| --- | --- |
| Status mesin | `NORMAL` / `ANOMALI`, device id, waktu update terakhir |
| Gerakan terdeteksi | Label pemenang + confidence |
| Anomaly score | Nilai + meter terhadap ambang |
| Waktu inferensi | Total, dipecah jadi DSP / klasifikasi / anomali |
| Anomaly score realtime | Grafik garis + garis ambang |
| Probabilitas kelas | Bar tiap label untuk window terakhir |
| Probabilitas kelas realtime | Grafik garis, satu garis per label |
| Perangkat | Uptime, heap, jumlah pesan, interval rata-rata |
| Payload terakhir | JSON mentah, berguna untuk debugging |
| Log koneksi | Riwayat event dashboard |

Tombol **Tabel** di tiap grafik membuka versi tabel dari data yang sama, supaya nilai
tetap terbaca tanpa bergantung pada warna.

## Catatan Desain

- Palet kategorikal dan status memakai urutan slot yang sudah divalidasi aman untuk
  buta warna. **Jangan mengacak urutan slot** `--series-1` sampai `--series-6` di
  `css/style.css` — urutan itulah mekanisme keamanannya.
- Warna status (hijau/merah) khusus untuk makna normal/anomali dan tidak pernah
  dipakai sebagai warna seri.
- Tema gelap punya nilai warna sendiri, bukan hasil pembalikan otomatis dari tema
  terang, supaya kontras tetap aman di kedua mode.

## Troubleshooting

| Gejala | Penyebab umum |
| --- | --- |
| Status berhenti di "Menghubungkan…" | URL harus `wss://` dan port `8884`, bukan `1883` |
| Terhubung tapi tidak ada data | Topic dashboard beda dengan `MQTT_TOPIC` di firmware |
| "Payload bukan JSON valid" di log | Ada `Serial.print` yang salah ikut ter-publish |
| Data berhenti setelah beberapa saat | Client ID bentrok di broker publik, ganti `DEVICE_ID` |
| Grafik kosong padahal log jalan | Browser memblokir CDN Chart.js, cek koneksi internet |
